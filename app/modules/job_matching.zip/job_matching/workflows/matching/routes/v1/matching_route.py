from fastapi import APIRouter, Depends, HTTPException
from app.core.base_model import APIResponse
from app.middleware.translation_manager import _
from app.exceptions.handlers import handle_exceptions
import logging

from app.modules.job_matching.workflows.matching.schemas.matching import JobMatchingRequest, JobMatchingResponse
from app.modules.job_matching.workflows.matching.repository.job_matching_repo import JobMatchingRepo

route = APIRouter(prefix="/job-matching", tags=["Job Matching"])

logger = logging.getLogger(__name__)

@route.post("/suggest", response_model=APIResponse)
@handle_exceptions
async def suggest_job_and_courses(
    request: JobMatchingRequest,
    repo: JobMatchingRepo = Depends(JobMatchingRepo)
) -> APIResponse:
    """
    Gợi ý khóa học và công việc dựa trên JD alignment từ cv_extraction
    
    - Nhận jd_alignment từ API cv_extraction
    - Trích xuất kỹ năng còn thiếu
    - Gợi ý khóa học online để bổ sung kiến thức
    - Gợi ý công việc phù hợp
    - Phân tích lộ trình nghề nghiệp
    """
    try:
        result = await repo.match_job(request)
        logger.info(f"Prompt gửi LLM: {request}")
        logger.info(f"LLM raw response: {result}")
        logger.info(f"Parsed result: {result}")
        return APIResponse(
            error_code=0,
            message=_("job_matching_successful"),
            data=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@route.get("/status/{session_id}")
@handle_exceptions
async def get_matching_status(
    session_id: str,
    repo: JobMatchingRepo = Depends(JobMatchingRepo)
) -> APIResponse:
    """
    Lấy trạng thái xử lý của một job matching session
    """
    try:
        status = await repo.get_matching_status(session_id)
        return APIResponse(
            error_code=0,
            message=_("status_retrieved_successfully"),
            data=status
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@route.get("/info")
@handle_exceptions
async def get_service_info(
    repo: JobMatchingRepo = Depends(JobMatchingRepo)
) -> APIResponse:
    """
    Lấy thông tin về Job Matching service
    """
    try:
        info = repo.get_service_info()
        return APIResponse(
            error_code=0,
            message=_("service_info_retrieved"),
            data=info
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@route.get("/health")
async def health_check() -> APIResponse:
    """
    Health check endpoint
    """
    return APIResponse(
        error_code=0,
        message=_("service_healthy"),
        data={"status": "healthy", "service": "job_matching"}
    ) 